#ifndef STATISTIQUE_H
#define STATISTIQUE_H
#include <iostream>
#include "User.h"
#include <map>
#include <unordered_map>
using namespace std;

class Statistique
{
    public:
        Statistique();
        ~Statistique();
        static int compteurTelechargements;
        //Autres methodes
        void PrintImagepop(User& utilisateur, const image imagesDisponibles[], int taille,const vector<Categorie>& categories);
        static void IncrementeCompteur();
        static void AfficherTotalTelechargements();
        static void IncrementerTelechargementsCategorie(const string& categorie);
        static void AfficherTelechargementsParCategorie();

    protected:


    private:
        static std::map<std::string,int> table;
         static std::unordered_map<string,int>telechargementsParCategorie;
};

#endif // STATISTIQUE_H
