#ifndef STATISTIQUES_H
#define STATISTIQUES_H
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <string>

class Statistiques
{
    public:
        //constructeur
        Statistique(const vector<string>&t,const vector<int>&l,vector<string>&c,const map<string,int>&telechargements,const map<string,int>&activite):titres(t),likes(l),categories(c),telechargementsParCategories(telechargements),activiteUtilisateurs(activite){}
        //Destructeur
        ~Statistiques();
        //Autres methodes
        int nombreImagesTelechargees()const;
        vector<string> imagesLesPlusPopulaires()const;
        map<string,int> nombreTelechargementsParCategorie() const;
        map<string,int>activiteDesUtilisateurs() const;
        void afficherStatistiques() const;
    protected:

    private:
        vector<string> titres;
        vector<int> likes;
        vector<string> categories;
        map<string,int> telechargementParCategorie;
        map<string,int> activiteUtilisateurs;
};

#endif // STATISTIQUES_H
