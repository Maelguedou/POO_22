#include "User.h"
#include "Statistique.h"
#include <iostream>
#include <algorithm>
using namespace std;
//constructeur
User::User(const string &nom , int id, bool fonction)
{
    Nom=nom;
    Id=id;
    Fonction=fonction;
}
//destructeur
User::~User()
{
    //dtor
}

//Autres methodes
/*bool User::Telecharger(const image& img) {

        cout << "Demande d'approbation pour l'image " << img.getTitre() << "..." << endl;

        if (img.Approuver()) {  // V�rifie si l'image est approuv�e
            magalerie.Stocker(img);
            cout << "Image " << img.getTitre() << " telechargee dans la galerie de " << Nom << "." << endl;
            Statistique::IncrementeCompteur();
            Statistique::IncrementerTelechargementsCategorie(img.getCat);
            return true;
        } else {
            cout << "Image " << img.getTitre() << " non approuvee." << endl;
            return false;
        }
    }
*/
bool User::Telecharger(const image& img, const vector<Categorie>& categories) {
    cout << "Demande d'approbation pour l'image " << img.getTitre() << "..." << endl;

    if (img.Approuver()) {
        magalerie.Stocker(img);
        cout << "Image " << img.getTitre() << " telechargee dans la galerie de " << Nom << "." << endl;
        Statistique::IncrementeCompteur();

        // Trouver et incr�menter la cat�gorie
        for (const auto& cat : categories) {
            const auto& images = cat.getImages();
            if (find(images.begin(), images.end(), img) != images.end()) {
                Statistique::IncrementerTelechargementsCategorie(cat.getNom());
                break;
            }
        }
        return true;
    } else {
        cout << "Image " << img.getTitre() << " non approuvee." << endl;
        return false;
    }
}
void User::Afficher_galerie() const {
cout << "Galerie de " << Nom <<" :"<< endl;
magalerie.Afficher_Images();
}
void User::AfficherImages_disponibles(const image imagesDisponibles[],int taille)const {
cout << "Images disponibles pour telechargement :" << endl;
for (int i=0; i< taille;++i){
   cout << imagesDisponibles[i].getTitre() << endl;
    cout << i+1 << "." << imagesDisponibles[i].getTitre() << endl;
}
}
void User::Images_fav(const image& img) {
    if (magalerie.ContientImage(img)) {
        magalerie.Stocker_fav(img);
        cout << "Image " << img.getTitre() << " ajout�e aux favoris de " << Nom << "." << endl;
    } else {
        cout << "Cette image n'est pas dans votre galerie. Ajoutez-la d'abord pour la mettre en favoris." << endl;
    }
}
void User::Print_favoris() const {
cout << "Voici vos favoris: " << Nom <<" :"<< endl;
magalerie.Afficher_Favoris();
}
void User::Supprimer_Image(const std::string){

}
void User::afficherCategories(const vector<Categorie>& categories) const {
    if (categories.empty()) {
        cout << "Aucune cat�gorie disponible." << endl;
    } else {
        cout << "Cat�gories et leurs images : " << endl;
        for (const auto& categorie : categories) {
            cout << "Cat�gorie : " << categorie.getNom() << endl;
            cout << "Images : " << endl;
            categorie.afficher_Images();
            cout << endl;
        }
    }
}
//Acesseur
//Mutateur
