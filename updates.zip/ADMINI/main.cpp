#include "image.h"
#include "Categorie.h"
#include "Galerie.h"
#include "Statistique.h"
#include "User.h"
#include "ADMIN.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main() {
    // Cr�ation des images disponibles
    image imagesDisponibles[] = {
        image("Chaussure.jpg", "Chaussure", "Image de chaussure", "jpg", false),
        image("Arbre.jpg", "Arbre", "Image d'un arbre", "png", false),
        image("Collier.jpg", "Collier", "Image de collier", "jpg", false)
    };
    int tailleImagesDisponibles = sizeof(imagesDisponibles) / sizeof(imagesDisponibles[0]);
    vector<Categorie> categories;
    Statistique stats;
    char continuer;
    do {
        // Saisie des informations de l'utilisateur
        string nom;
        int id;
        bool fonction;

        cout << "Entrez votre nom : ";
        cin >> nom;

        cout << "Entrez votre ID : ";
        cin >> id;

        cout << "�tes-vous administrateur ? (1 pour Oui, 0 pour Non) : ";
        cin >> fonction;

        if (fonction) {
            ADMIN admin(nom, id);

            cout << "Bienvenue, administrateur " << nom << "!" << endl;

            // Exemple d'options pour l'ADMIN
            char choixAdmin;
            do {
                cout << "\nOptions de l'administrateur :\n";
                cout << "1. Ajouter une cat�gorie\n";
                cout << "2. Approuver ou rejeter une image\n";
                cout << "3. Afficher les cat�gories et images\n";
                cout << "4. Supprimer une cat�gorie\n";
                cout << "5. T�l�charger une image\n";
                cout << "6. Afficher la galerie\n";
                cout << "7. Ajouter une image aux favoris\n";
                cout << "8. Afficher les favoris\n";
                cout << "9. Afficher les Statistiques\n";
                cout << "0. Quitter\n";
                cout << "Choisissez une option : ";
                cin >> choixAdmin;

                switch (choixAdmin) {
                    case '1': {
                        string nomCategorie;
                        cout << "Nom de la nouvelle cat�gorie : ";
                        cin >> nomCategorie;
                        admin.Cree_Cat_Image(categories, nomCategorie);
                        break;
                    }
                    case '2': {
                        int index;
                        bool approuver;
                        cout << "Index de l'image � approuver/rejeter : ";
                        cin >> index;
                        cout << "Approuver (1) ou Rejeter (0) : ";
                        cin >> approuver;
                        admin.ApprouverImage(imagesDisponibles[index - 1], approuver);
                        break;
                    }
                    case '3':
                        admin.AfficherCategories(categories);
                        break;
                    case '4': {
                        string nomCat;
                        cout << "Nom de la categorie � supprimer : ";
                        cin >> nomCat;
                        admin.Supprimer_Cat_Image(categories, nomCat);
                        break;
                    } // Fin case '4'
                    case '5': {
                        int index;
                        admin.AfficherImages_disponibles(imagesDisponibles, tailleImagesDisponibles);
                        admin.AfficherCategories(categories);
                        cout << "Entrez l'index de l'image � telecharger : ";
                        cin >> index;
                        admin.Telecharger(imagesDisponibles[index - 1],categories);
                        break;
                    }
                    case '6':
                        admin.Afficher_galerie();
                        break;
                    case '7': {
                        int index;
                        cout << "Entrez l'index de l'image � ajouter aux favoris : ";
                        cin >> index;
                        admin.Images_fav(imagesDisponibles[index - 1]);
                        break;
                    }
                    case '8':
                        admin.Print_favoris();
                        break;
                    case '9':
                        cout << "Statistiques :\n";

                        Statistique::AfficherTotalTelechargements();
                        stats.PrintImagepop(admin,imagesDisponibles,tailleImagesDisponibles,categories);
                        stats.AfficherTelechargementsParCategorie();
                        break;
                    case '0':
                         char confirmation;
                            cout << "Etes-vous sur de vouloir quitter ? (y/n) : ";
                            cin >> confirmation;
                            if (confirmation == 'y' || confirmation == 'Y') {
                                cout << "Au revoir, " << nom << "!" << endl;
                                return 0; // Quitter le programme si l'administrateur choisit de quitter
                            } else {
                                cout << "Retour au menu des options." << endl;
                            }
                            break;
                }
            } while (true);
        } else {
            User utilisateur(nom, id, false);
            cout << "Bienvenue, utilisateur " << nom << "!" << endl;

            // Exemple d'options pour le USER
            char choixUser;
            do {
                cout << "\nOptions de l'utilisateur :\n";
                cout << "1. T�l�charger une image\n";
                cout << "2. Afficher la galerie\n";
                cout << "3. Ajouter une image aux favoris\n";
                cout << "4. Afficher les favoris\n";
                cout << "5. Quitter\n";
                cout << "Choisissez une option : ";
                cin >> choixUser;

                switch (choixUser) {
                    case '1': {
                        int index;
                        utilisateur.afficherCategories(categories);
                        utilisateur.AfficherImages_disponibles(imagesDisponibles, tailleImagesDisponibles);
                        cout << "Entrez l'index de l'image � t�l�charger : ";
                        cin >> index;
                        utilisateur.Telecharger(imagesDisponibles[index - 1],categories);
                        break;
                    }
                    case '2':
                        utilisateur.Afficher_galerie();
                        break;
                    case '3': {
                        int index;
                        cout << "Entrez l'index de l'image � ajouter aux favoris : ";
                        cin >> index;
                        utilisateur.Images_fav(imagesDisponibles[index - 1]);
                        break;
                    }
                    case '4':
                        utilisateur.Print_favoris();
                        break;
                }
            } while (choixUser != '5');
        }

        cout << "Voulez-vous recommencer avec un nouvel utilisateur ? (y/n) : ";
        cin >> continuer;
    } while (continuer == 'y' || continuer == 'Y');

    return 0;
}
