#ifndef USER_H
#define USER_H
#include <iostream>
#include "Galerie.h"
#include "Categorie.h"
#include "image.h"
using namespace std;


class User
{
    public:
        User(const string &nom, int id, bool fonction);
        ~User();
        //Autres methodes
        void AfficherImages_disponibles(const image imgesDisponibles[],int taille)const;
        void Afficher_galerie()const;
        bool Telecharger(const image& img, const vector<Categorie>& categories);
        void Retirer_favoris();
        void Incrementer();
        void Images_fav(const image& img);
        void Print_favoris()const;
        void Supprimer_Image(const std::string);
        void afficherCategories(const vector<Categorie>& categories) const;


    protected:


    private:
    string Nom;
    int Id;
    bool Fonction;
    Galerie magalerie;

};

#endif // USER_H
