#ifndef ADMIN_H
#define ADMIN_H

#include "User.h"
#include "Categorie.h"
#include "image.h"
#include <vector>
#include <string>

class ADMIN : public User {
public:
    // Constructeur et destructeur
    ADMIN(const string& nom, int id);
    ~ADMIN();

    // M�thodes sp�cifiques � l'administrateur
    bool Approuver_image(const image& img, bool value);
    bool Supprimer_Cat_Image(vector<Categorie>& categories, const string& nom);
    bool Rejeter_image(const image& img);
    void Add_user(const string& nom, int id);
    bool Cree_Cat_Image(vector<Categorie>& categories, const string& nom);
    void Editer_Cat_Image(Categorie& categorie, const string& newName);
    bool Ajouter_Image_Dans_Categorie(std::vector<Categorie>& categories, const image& img, const std::string& nomCategorie);
    void AfficherCategories(const vector<Categorie>& categories) const;
    void Ranger_Image(std::vector<Categorie>& categories, const image& img, const std::string& nomCategorie);
    void Editer_Cat_Image(vector<Categorie>& categories, const string& ancienNom, const string& nouveauNom) ;
    void ApprouverImage(image& img,bool approuver);
    void ajouterImageACategorie(image& img, Categorie& cat);
};


#endif // ADMIN_H
