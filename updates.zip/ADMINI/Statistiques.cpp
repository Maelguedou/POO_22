#include "Statistiques.h"
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <string>
using namespace std;

Statistiques::Statistique(const vector<string>&t,const vector<int>&l,vector<string>&c,const map<string,int>&telechargements,const map<string,int>&activite):titres(t),likes(l),categories(c),telechargementsParCategories(telechargements),activiteUtilisateurs(activite){}


Statistiques::~Statistiques()
{
    //dtor
}


int nombreImagesTelechargees()const{
        return titres.size();
    }

vector<string> imagesLesPlusPopulaires()const {
         int maxLikes=*max_element(likes.begin(),likes.end());
         vector<string>imagesPopulaires;
         for(size_t i=0; i<likes.size(); ++i) {
            if (likes[i]==maxeLikes){

                imagesPopulaires.push_back(titres[i]);
            }
         }
           return imagesPopulaires;
     }

map<string,int> nombreTelechargementsParCategorie() const {
     return telechargementsParCategorie;
     }
map<string,int>activiteDesUtilisateurs() const {

         return activiteUtilisateurs;

      }
void afficherStatistiques() const {

        cout<<"Nombre total d'images t�l�charg�es: ";
        for( const auto& img: populaires){
            cout<<img<<"";

        }
          cout<<"\n";
          cout<<"Nombre de t�l�chargements par cat�gorie: \n";
          for( const auto& pair: telechargementsParCategorie){

          cout<<"_"<<pair.first<<":"<<pair.second<<"t�l�chargements\n";
          }
          cout<<"Activit� des utilisateurs:\n";
          for(const auto& pair : activiteUtilisateurs){
             cout<<"_"<<pair.first<<":"<<pair.second<<"actions\n";;
          }

       }
 }


















