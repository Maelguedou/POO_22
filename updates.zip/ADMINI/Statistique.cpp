/*#include "Statistique.h"
#include <iostream>
#include <algorithm>


Statistique::Statistique()
{
    //ctor
}

Statistique::~Statistique()
{
    //dtor
}
//Autres methodes
int Statistique::compteurTelechargements = 0;  // Initialisation du compteur global

void Statistique::IncrementeCompteur() {
    compteurTelechargements++;
}

void Statistique::AfficherTotalTelechargements() {
    cout << "Nombre total d'images telechargees sur le site : " << compteurTelechargements << endl;
}

 void Statistique::PrintImagepop(User& utilisateur, const image imagesDisponibles[], int taille) {
        for (int i = 0; i < taille; ++i) {
            if (utilisateur.Telecharger(imagesDisponibles[i])) {
                std::string titre = imagesDisponibles[i].getTitre();
                table[titre]++; // Incr�mente le compteur de t�l�chargements pour cette image
            }
        }

        // Affiche les images populaires en les triant par nombre de t�l�chargements
        std::vector<std::pair<std::string, int>> sortedImages(table.begin(), table.end());
        std::sort(sortedImages.begin(), sortedImages.end(),
                  [](const auto& a, const auto& b) { return a.second > b.second; });

        std::cout << "Images populaires :\n";
        for (const auto& img : sortedImages) {
            std::cout << img.first << " : " << img.second << " t�l�chargements\n";
        }
    };*/




/*#include "Statistique.h"
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <string>
using namespace std;
class Statistique {
private:
    vector<string> titres;
    vector<int> likes;
    vector<string> categories;
    map<string,int> telechargementParCategorie;
    map<string,int> activiteUtilisateurs;
public:
    Statistique(const vector<string>&t,const vector<int>&l,vector<string>&c,const map<string,int>&telechargements,const map<string,int>&activite):titres(t),likes(l),categories(c),telechargementsParCategories(telechargements),activiteUtilisateurs(activite){}

    int nombreImagesTelechargees()const{
        return titres.size();
    }

     vector<string> imagesLesPlusPopulaires()const {
         int maxLikes=*max_element(likes.begin(),likes.end());
         vector<string>imagesPopulaires;
         for(size_t i=0; i<likes.size(); ++i) {
            if (likes[i]==maxeLikes){

                imagesPopulaires.push_back(titres[i]);
            }
         }
           return imagesPopulaires;
     }

     map<string,int> nombreTelechargementsParCategorie() const {
     return telechargementsParCategorie;
     }
      map<string,int>activiteDesUtilisateurs() const {

         return activiteUtilisateurs;

      }
       void afficherStatistiques() const {

        cout<<"Nombre total d'images t�l�charg�es: ";
        for( const auto& img: populaires){
            cout<<img<<"";

        }
          cout<<"\n";
          cout<<"Nombre de t�l�chargements par cat�gorie: \n";
          for( const auto& pair: telechargementsParCategorie){

          cout<<"_"<<pair.first<<":"<<pair.second<<"t�l�chargements\n";
          }
          cout<<"Activit� des utilisateurs:\n";
          for(const auto& pair : activiteUtilisateurs){
             cout<<"_"<<pair.first<<":"<<pair.second<<"actions\n";;
          }

       }
 }*/

/*int Statistique::compteurTelechargements = 0;  // Initialisation du compteur global

void Statistique::IncrementeCompteur() {
    compteurTelechargements++;
}

void Statistique::AfficherTotalTelechargements() {
    cout << "Nombre total d'images telechargees sur le site : " << compteurTelechargements << endl;
}

 void Statistique::PrintImagepop(User& utilisateur, const image imagesDisponibles[], int taille) {
        for (int i = 0; i < taille; ++i) {
            if (utilisateur.Telecharger(imagesDisponibles[i])) {
                std::string titre = imagesDisponibles[i].getTitre();
                table[titre]++; // Incr�mente le compteur de t�l�chargements pour cette image
            }
        }

        // Affiche les images populaires en les triant par nombre de t�l�chargements
        std::vector<std::pair<std::string, int>> sortedImages(table.begin(), table.end());
        std::sort(sortedImages.begin(), sortedImages.end(),
                  [](const auto& a, const auto& b) { return a.second > b.second; });

        std::cout << "Images populaires :\n";
        for (const auto& img : sortedImages) {
            std::cout << img.first << " : " << img.second << " t�l�chargements\n";
        }
    }
};*/

#include "Statistique.h"
#include <iostream>
#include <algorithm> // Pour std::sort
#include <vector>
#include <map>
using namespace std;
std::map<std::string,int>Statistique::table;
int Statistique::compteurTelechargements = 0;  // Initialisation du compteur global

Statistique::Statistique() {
    // ctor
}

Statistique::~Statistique() {
    // dtor
}

void Statistique::IncrementeCompteur() {
    compteurTelechargements++;
}

void Statistique::AfficherTotalTelechargements() {
    std::cout << "Nombre total d'images telechargees sur le site : " << compteurTelechargements << std::endl;
}

void Statistique::PrintImagepop(User& utilisateur, const image imagesDisponibles[], int taille,const vector<Categorie>& categories) {
    for (int i = 0; i < taille; ++i) {
        if (utilisateur.Telecharger(imagesDisponibles[i],categories)) {
            std::string titre = imagesDisponibles[i].getTitre();
            table[titre]++; // Incr�mente le compteur de t�l�chargements pour cette image
            IncrementeCompteur();  // Incr�mente le compteur global
        }
    }

    // Affiche les images populaires en les triant par nombre de t�l�chargements
    std::vector<std::pair<std::string, int>> sortedImages(table.begin(), table.end());
    std::sort(sortedImages.begin(), sortedImages.end(),
              [](const auto& a, const auto& b) { return a.second > b.second; });

    std::cout << "Images populaires :\n";
    for (const auto& img : sortedImages) {
        std::cout << img.first << " : " << img.second << " t�l�chargements\n";
    }
}

    /*static void Statistique::AfficherTelechargementsParCategorie(const vector<Categorie>& categories) {
        cout << "\nNombre de t�l�chargements par cat�gorie :\n";
        for (const auto& cat : categories) {
            cout << "Cat�gorie: " << cat.nom << " - T�l�chargements: " << cat.getTelechargements() << endl;
        }
    }*/

    void Statistique::IncrementerTelechargementsCategorie(const string& categorie) {
        telechargementsParCategorie[categorie]++;
    }

    void Statistique:: AfficherTelechargementsParCategorie() {
        cout << "Nombre de telechargements par categorie :" << endl;
        for (const auto& entry : telechargementsParCategorie) {
            cout << "Categorie " << entry.first << " : " << entry.second << " t�l�chargements" << endl;
        }
    };

// Initialisation de la map statique
unordered_map<string, int> Statistique::telechargementsParCategorie;



















