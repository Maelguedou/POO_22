#ifndef GALERIE_H
#define GALERIE_H
#include<vector>
#include<string>
#include "image.h"

class Galerie
{
    public:
        Galerie();
        ~Galerie();
        void Stocker_fav(const image& img);
       void Stocker(const image& img);
       void Afficher_Images()const;
       void Afficher_Favoris() const;
       bool ContientImage(const image& img)const;

    protected:

    private:
    std::vector<image>galerie;
    std::vector<image>favoris;
};

#endif // GALERIE_H*/
