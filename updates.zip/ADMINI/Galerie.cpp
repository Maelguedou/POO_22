#include "Galerie.h"
#include <iostream>
//Constructeur
Galerie::Galerie()
{

}
//Destructeur
Galerie::~Galerie()
{

}
//Autres methodes
void Galerie::Stocker(const image& img) {
   galerie.push_back(img);
}
 void Galerie::Afficher_Images()const {
    for (const auto& img : galerie) {
        std::cout << "Nom: " << img.getNom()
                  << ", Titre: " << img.getTitre()
                  << ", Format: " << img.getFormat()
                  << ", Description: " << img.getDescription() << std::endl;
    }
}
void Galerie::Afficher_Favoris() const {
    if (favoris.empty()){
        std::cout << "Aucun favoris disponible."<< std::endl;
    }else {
        std::cout << "Favoris : " << std::endl;
        for(const auto& fav: favoris){
            fav.Afficher();
        }
    }
}
void Galerie::Stocker_fav(const image& img){
favoris.push_back(img);
}
bool Galerie::ContientImage(const image& img)const {
    for (const auto& storedImg : galerie){
        if (storedImg.getNom()==img.getNom()){
            return true;
        }
    }
    return false;
}
//Acesseur

//Mutateur
