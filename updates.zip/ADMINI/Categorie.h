#ifndef CATEGORIE_H
#define CATEGORIE_H
#include <iostream>
#include <vector>
#include "image.h"

using namespace std;
class Categorie
{
    public:
        Categorie();
        Categorie(const string& nom);
        ~Categorie();

        //Autres methodes
        void Ajouter_Image(const image& img);
        void Supprimer_Image(const string& nom);
        void afficher_Images()const;
        void incrementerTelechargement();

        //Acesseur
        string getNom() const;
        int getTelechargements() const;
        const vector<image>& getImages() const;
        //Mutateur
        void setNom(const string& nom);
    protected:

    private:
        string Nom;
        vector<image> images;
        int telechargements;
};

#endif // CATEGORIE_H
