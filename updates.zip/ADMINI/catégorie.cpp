/*#include "cat�gorie.h"

cat�gorie::cat�gorie()
{
    //ctor
    Categorie::Categorie()
{

}

Categorie::Categorie(string nom)
{
    Nom=nom;
}
}

cat�gorie::~cat�gorie()
{
    //dtor
    Categorie::~Categorie()
{

}

}
// Autres m�thodes
void Categorie::Ajouter_Image(const image& img) {
    images.push_back(img);
    cout << "Image ajout�e � la cat�gorie: " << Nom << endl;
}

void Categorie::Supprimer_Image(const string& nom) {
    for (auto it = images.begin(); it != images.end(); ++it) {
        if (it->getNom() == nom) {
            images.erase(it);
            cout << "Image supprim�e: " << nom << endl;
            return;
        }
}
// Accesseur
string Categorie::getNom() const {
    return Nom;
}
*/
