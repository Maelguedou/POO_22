#ifndef IMAGE_H
#define IMAGE_H

#include <iostream>
using namespace std;

class image
{
    public:
        //Constructeur
        image();
        image(string nom,string titre,string description,string format,bool statut);

        //image(string Nom,int Nbre_T�l�chargements,string Titre,string Description,string Format,bool statut)
        //Destructeur
        ~image();

             bool operator==(const image& other) const {
                    return (Nom == other.Nom &&
                        Titre == other.Titre &&
                        Description == other.Description &&
                        Format == other.Format &&
                        statut == other.statut);}


        //Autres m�thodes
       void Afficher()const;
        //Accesseur
        string getNom() const;
        string getTitre() const;
        string getDescription() const;
        string getFormat() const;
        bool Approuver()const ;
        //Mutateur
        void setStatut(bool stu);
    protected:

    private:
    string Categorie;
    string Nom;
    //int Nbre_T�l�chargement;
    string Titre;
    string Description;
    string Format;
    bool statut;

};

#endif // IMAGE_H
