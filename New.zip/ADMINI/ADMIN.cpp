#include "ADMIN.h"
#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Constructeur
ADMIN::ADMIN(const string& nom, int id) : User(nom, id, true) {}

// Destructeur
ADMIN::~ADMIN() {}

// Autres methodes
bool ADMIN::Ajouter_Image_Dans_Categorie(std::vector<Categorie>& categories, const image& img, const std::string& nomCategorie) {
    for (auto& cat : categories) {
        if (cat.getNom() == nomCategorie) {
            cat.Ajouter_Image(img); // Ajoute l'image dans la cat�gorie
            std::cout << "Image " << img.getTitre() << " ajout�e � la cat�gorie " << nomCategorie << std::endl;
            return true;
        }
    }
    std::cout << "Cat�gorie " << nomCategorie << " non trouv�e." << std::endl;
    return false;
}
bool ADMIN::Approuver_image(const image& img, bool value) {
    if (value) {
        cout << "Image approuv�e: " << img.getTitre() << endl;
        return true;
    } else {
        cout << "Image rejet�e: " << img.getTitre() << endl;
        return false;
    }
}

// Supprimer une cat�gorie d'images
bool ADMIN::Supprimer_Cat_Image(vector<Categorie>& categories, const string& nom) {
     for (auto it = categories.begin(); it !=categories.end(); ++it)
        {
        if (it->getNom() == nom) {
                categories.erase(it);
            cout << "Categorie supprim�e" << nom << endl;
            return true;
        }
    }
     cout << "Categorie" << nom <<" non trouvee" << endl;
     return false;
}

// Rejeter une image
bool ADMIN::Rejeter_image(const image& img) {
    cout << "Image rejet�e: " << img.getTitre() << endl;
    return true;
}

// Ajouter un utilisateur
void ADMIN::Add_user(const string& nom, int id) {
    cout << "Nouvel utilisateur ajout�: " << nom << ", ID: " << id << endl;

}

// Cr�er une nouvelle cat�gorie
bool ADMIN::Cree_Cat_Image(vector<Categorie>& categories, const string& nom) {
    for (const auto& cat : categories) {
        if (cat.getNom() == nom) {
            cout << "Cat�gorie d�j� existante.\n";
            return false;
        }
    }
    categories.push_back(Categorie(nom));
    cout << "Nouvelle cat�gorie cr��e: " << nom << endl;
    return true;
}

// �diter le nom d'une cat�gorie
void ADMIN::Editer_Cat_Image(Categorie& categorie, const string& newName) {
    categorie.setNom(newName); // Change le nom de la cat�gorie
    cout << "Nom de la cat�gorie modifi� en: " << newName << endl;
}
