#include "image.h"
#include "Galerie.h"
#include "User.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main() {
    // Cr�ation des images disponibles
    image imagesDisponibles[] = {
        image("Chaussure.jpg", "Chaussure", "Image de chaussure", "jpg"),
        image("Arbre.jpg", "Arbre", "Image d'un arbre", "png"),
        image("Collier.jpg", "Collier", "Image de collier", "jpg")
    };
    int tailleImagesDisponibles = sizeof(imagesDisponibles) / sizeof(imagesDisponibles[0]);

    char continuer; // Variable pour d�cider si l'utilisateur veut recommencer
    char fav;
    do {
        // Saisie des informations de l'utilisateur
        string nom;
        int id;
        bool fonction;

        cout << "Entrez votre nom : ";
        cin >> nom;

        cout << "Entrez votre ID : ";
        cin >> id;

        cout << "�tes-vous administrateur ? (1 pour Oui, 0 pour Non) : ";
        cin >> fonction;

        // Cr�ation de l'utilisateur
        User utilisateur(nom, id, fonction);

        // Interaction pour t�l�charger des images si l'utilisateur n'est pas administrateur
        if (!fonction) {
            char choix;
            do {
                // Affichage des images disponibles pour t�l�chargement
                utilisateur.AfficherImages_disponibles(imagesDisponibles, tailleImagesDisponibles);

                cout << "Entrez le numero de l'image que vous souhaitez telecharger (1-" << tailleImagesDisponibles << ") : ";
                int numeroImage;
                cin >> numeroImage;

                // Validation du choix
                if (numeroImage > 0 && numeroImage <= tailleImagesDisponibles) {
                    utilisateur.Telecharger(imagesDisponibles[numeroImage - 1]);
                } else {
                    cout << "Choix invalide, r�essayez." << endl;
                }

                // Demande si l'utilisateur veut continuer � t�l�charger
                cout << "Voulez-vous telecharger une autre image ? (y/n) : ";
                cin >> choix;
                //Ajout d'images aux favoris
                cout << "Avez vous des images favoris ? (y/n) : ";
                cin >> fav;
                if (fav=='y' || fav=='Y'){
                    cout << "Choisissez le numero de votre image favoris (1-" << tailleImagesDisponibles << ") : ";
                    int numero;
                    cin >>numero;
                    if (numero> 0 && numero <= tailleImagesDisponibles) {
                        utilisateur.Images_fav(imagesDisponibles[numero  - 1]);}
                    else {
                        cout << "Choix invalide, r�essayez." << endl;
                }

                // Demande si l'utilisateur veut continuer � t�l�charger
                cout << "Voulez-vous telecharger une autre image ? (y/n) : ";
                cin >> choix;
                }

            } while (choix == 'y' || choix == 'Y');
        } else {
            cout << "Vous �tes administrateur, vous ne pouvez pas telecharger d'images." << endl;
        }

        // Affichage de la galerie personnelle de l'utilisateur
        utilisateur.Afficher_galerie();
        utilisateur.Print_favoris();

        // Demande si l'utilisateur veut recommencer
        cout << "Voulez-vous revenir au d�but ? (y/n) : ";
        cin >> continuer;

    } while (continuer == 'y' || continuer == 'Y');

    return 0;
}
