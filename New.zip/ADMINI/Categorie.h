#ifndef CATEGORIE_H
#define CATEGORIE_H

#include <iostream>
#include <vector>
#include "image.h"

using namespace std;

class Categorie
{
    public:
        Categorie();
        // Constructeur
        Categorie(const string& nom);

        // Destructeur
        ~Categorie();

        // Autres m�thodes
        void Ajouter_Image(const image& img);
        void Supprimer_Image(const string& nom);
        void afficher_Images() const;
        // Accesseur
        string getNom() const;
        //Mutateur
        void setNom(const string& nom);

    protected:

    private:
        string Nom;
        vector<image> images;
};

#endif // CATEGORIE_H
