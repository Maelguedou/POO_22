#include "User.h"
#include <iostream>
using namespace std;
//constructeur
User::User(const string &nom , int id, bool fonction)
{
    Nom=nom;
    Id=id;
    Fonction=fonction;
}
//destructeur
User::~User()
{
    //dtor
}

//Autres methodes
void User::Telecharger(const image& img){
    if (!Fonction){
    magalerie.Stocker(img);
    cout << "Image " <<img.getTitre() <<"t�l�charg�e dans la galerie de " << Nom << "." << endl;
    }else {cout << "Les images peuvent pas �tre t�l�charg�es." << endl;}
}
void User::Afficher_galerie() const {
cout << "Galerie de " << Nom <<" :"<< endl;
magalerie.Afficher_Images();
}
void User::AfficherImages_disponibles(const image imagesDisponibles[],int taille)const {
cout << "Images disponibles pour telechargement :" << endl;
for (int i=0; i< taille;++i){
   cout << imagesDisponibles[i].getTitre() << endl;
    cout << i+1 << "." << imagesDisponibles[i].getTitre() << endl;
}
}
void User::Images_fav(const image& img) {
    if (magalerie.ContientImage(img)) {
        magalerie.Stocker_fav(img);
        cout << "Image " << img.getTitre() << " ajout�e aux favoris de " << Nom << "." << endl;
    } else {
        cout << "Cette image n'est pas dans votre galerie. Ajoutez-la d'abord pour la mettre en favoris." << endl;
    }
}
void User::Print_favoris() const {
cout << "Voici vos favoris: " << Nom <<" :"<< endl;
magalerie.Afficher_Favoris();
}
void User::Supprimer_Image(const std::string){

}
//Acesseur
//Mutateur
