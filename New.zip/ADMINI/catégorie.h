/*#ifndef CATEGORIE_H
#define CATEGORIE_H

#include <iostream>
#include <list>
#include "image.h"

using namespace std;
class cat�gorie
{
    public:
        // Constructeurs
        cat�gorie();
        Categorie(string nom);

        // Destructeur
        ~Categorie();

        // Autres m�thodes
        void Ajouter_Image(const image& img)
        void Supprimer_Image(const string& nom)

        // Accesseurstring
        getNom() const;
    protected:
        // Affichage
        void Afficher_Images() const;

    private:
        string Nom;
        list<image> images;
}

#endif // CAT�GORIE_H
*/
