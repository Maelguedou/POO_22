#ifndef USER_H
#define USER_H
#include <iostream>
#include "Galerie.h"
#include "image.h"
using namespace std;


class User
{
    public:
        User(const string &nom, int id, bool fonction);
        ~User();
        //Autres methodes
        void AfficherImages_disponibles(const image imgesDisponibles[],int taille)const;
        void Afficher_galerie()const;
        void Telecharger(const image& img);
        void Retirer_favoris();
        void Incrementer();
        void Images_fav(const image& img);
        void Print_favoris()const;
        void Supprimer_Image(const std::string);


    protected:


    private:
    string Nom;
    int Id;
    bool Fonction;
    Galerie magalerie;

};

#endif // USER_H
