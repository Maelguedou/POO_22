#include "Categorie.h"
#include <iostream>


Categorie::Categorie()
{

}
Categorie::Categorie(const string& nom)
{
    Nom=nom;
}

Categorie::~Categorie()
{
    //dtor
}
// Autres m�thodes
void Categorie::Ajouter_Image(const image& img)
 {
    images.push_back(img);
    cout << "Image ajout�e � la cat�gorie: " << Nom << endl;
 }

void Categorie::Supprimer_Image(const string& nom) {
    for (auto it = images.begin(); it != images.end(); ++it) {
        if (it->getNom() == nom) {
            images.erase(it);
            cout << "Image supprim�e: " << nom << endl;
            return;
        }
    }cout <<"Image non trouv�e:" << nom <<endl;
}
void Categorie::afficher_Images()const {
    for (const auto& img :images){
    cout << img.getTitre() << endl;
    }
}
// Accesseur
std::string Categorie::getNom() const {
    return Nom;
 }
 //Mutateur
 void Categorie::setNom(const string& nom)
 {
    Nom=nom ;
 }
